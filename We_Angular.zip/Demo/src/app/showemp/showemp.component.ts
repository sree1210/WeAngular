import { Component, OnInit } from '@angular/core';
import { EmpService } from '../emp.service';

@Component({
  selector: 'app-showemp',
  templateUrl: './showemp.component.html',
  styleUrls: ['./showemp.component.css']
})
export class ShowempComponent implements OnInit {
  employees:any;

  constructor(private service: EmpService) {
  }

  ngOnInit(): void {
    this.service.showAllEmployees().subscribe((result)=> {this.employees=result;});
  }

  deleteEmp(employee: any){
     this.service.deleteEmp(employee).subscribe((result: any)=>{
       const i = this.employees.findIndex((element:any)=>{
         return element._id === employee._id;
     });
     this.employees.splice(i,1);
  });
  }
}
