import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hrhomepage',
  templateUrl: './hrhomepage.component.html',
  styleUrls: ['./hrhomepage.component.css']
})
export class HrhomepageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
